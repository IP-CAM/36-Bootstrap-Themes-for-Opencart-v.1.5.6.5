****************************************************  
*  ____            _          ____        _        *
* |  _ \          | |        |  _ \      | |       *
* | |_) | ___  ___| |_ ______| |_) |_   _| |_ ___  *
* |  _ < / _ \/ __| __|______|  _ <| | | | __/ _ \ *
* | |_) |  __/\__ \ |_       | |_) | |_| | ||  __/ *
* |____/ \___||___/\__|      |____/ \__, |\__\___| *
*                                    __/ |         *
*                                   |___/          *
****************************************************
*     Mod: Theme Switcher                          *
* Version: 1.0                                     *
*  Author: Best-Byte - www.best-byte.com           *
* Contact: support@best-byte.com                   *
*    Date: April 2013                              *
****************************************************

This is an updated vQmod version of an extension created by Fido-X

REQUIREMENTS:
=============
Opencart Versions > or = 1.5.1

vQmod versions > or = 2.1

You must have vQmod installed to use this!

Download vQmod here: http://www.vqmod.com

WHAT DOES IT DO:
================
This extension is a module that enables you to select the theme that you want displayed.

This is especially usefull if you have demo theme's that you want to showcase.

FEATURE OVERVIEW:
=================
* Drop down selection in module includes all of the themes you have installed for your store.
* Just select the theme you want displayed and it changes to that theme.
* Admin settings include Layout, Position, Status and Sort Order.
* Detailed instructions included in download.

LICENSE:
========
This is a free extension made by Best-Byte and can only be used for personal use. 
You can modify it as you like as long as all references to Best-Byte are left intact. 
You can not sell, copy or distribute any portion of this mod under any circumstances without our consent.

INSTALLATION:
=============
1) ALWAYS make a backup of your site before applying new mods etc. Better to be safe than sorry.

2) Upload the contents of the folder called upload (which are the folders called "admin" and "catalog" and "vqmod") 
   to the same place you have OpenCart installed at. These are new files and no files should be overwritten.   

3) Login to your Administration panel. Select "System > Users > User Groups". Edit the "Top Administrator" group.
   Make sure "module/theme_switcher" is checked in both the Access Permission and Modify Permission lists. Save.
   
4) Enable the extension by going to "Extensions > Modules > Theme Switcher", click "Install" and then "Edit".
   Select the settings you would like for the module. Click Save.
        
5) That is all. Thank you for downloading and using this mod. If you like this mod please provide your star rating for it!
   
CHANGE LOG
===========
April 5th, 2013
Version 1.0
Initial release.          